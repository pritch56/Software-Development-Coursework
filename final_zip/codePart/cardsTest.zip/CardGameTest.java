import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.DisplayName;
import static org.junit.jupiter.api.Assertions.*;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

@DisplayName("Card Game integration tests")
public class CardGameTest {
    
    private final String testPackFile = "test_pack_integration.txt";
    private final ByteArrayOutputStream outputContent = new ByteArrayOutputStream();
    private final PrintStream originalOut = System.out;
    
    @BeforeEach
    public void setUp() throws IOException {
        System.setOut(new PrintStream(outputContent));
        
        // pack for 2 people
        try (PrintWriter writer = new PrintWriter(new FileWriter(testPackFile))) {
            writer.println("1");
            writer.println("1");
            writer.println("1");
            writer.println("1");

            writer.println("2");
            writer.println("3");
            writer.println("4");
            writer.println("5");

            for (int i = 6; i <= 13; i++) {
                writer.println(i);
            }
        }
    }
    
    @AfterEach
    public void tearDown() {
        System.setOut(originalOut);
        
        deleteTestFiles();
    }
    
    private void deleteTestFiles() {
        String[] filesToDelete = {
            testPackFile,
            "player1_output.txt",
            "player2_output.txt", 
            "player3_output.txt",
            "player4_output.txt",
            "deck1_output.txt",
            "deck2_output.txt",
            "deck3_output.txt", 
            "deck4_output.txt",
            "test_deck_1.txt",
            "test_deck_2.txt",
            "invalid_pack.txt",
            "negative_pack.txt"
        };
        
        for (String filename : filesToDelete) {
            File file = new File(filename);
            if (file.exists()) {
                file.delete();
            }
        }
    }

    @Test
    @DisplayName("create valid card with positive denomination")
    public void testValidCardCreation() {
        Card card = new Card(5);
        assertEquals(5, card.getDenomination());
    }
    
    @Test
    @DisplayName("should create card with zero denomination")
    public void testZeroDenominationCard() {
        Card card = new Card(0);
        assertEquals(0, card.getDenomination());
    }
    
    @Test
    @DisplayName("should throw exception for negative denomination")
    public void testNegativeDenominationThrowsException() {
        assertThrows(IllegalArgumentException.class, () -> new Card(-1));
    }
    
    @Test
    @DisplayName("implement card equality correctly")
    public void testCardEquality() {
        Card card1 = new Card(5);
        Card card2 = new Card(5);
        Card card3 = new Card(3);
        
        assertEquals(card1, card2);
        assertNotEquals(card1, card3);
        assertNotEquals(card1, null);
        assertNotEquals(card1, "not a card");
    }
    
    @Test
    @DisplayName("maintain consistent hashCode")
    public void testCardHashCode() {
        Card card1 = new Card(7);
        Card card2 = new Card(7);
        
        assertEquals(card1.hashCode(), card2.hashCode());
    }
    
    @Test
    @DisplayName("return correct string representation")
    public void testCardToString() {
        Card card = new Card(10);
        assertEquals("10", card.toString());
    }
    
    @Test
    @DisplayName("maintain immutability under concurrent access")
    public void testCardImmutability() throws InterruptedException {
        Card card = new Card(42);
        ExecutorService executor = Executors.newFixedThreadPool(10);
        
        for (int i = 0; i < 100; i++) {
            executor.submit(() -> assertEquals(42, card.getDenomination()));
        }
        
        executor.shutdown();
        assertTrue(executor.awaitTermination(5, TimeUnit.SECONDS));
    }

    @Test
    @DisplayName("create deck with correct initial state")
    public void testCardDeckCreation() {
        CardDeck deck = new CardDeck(1);
        assertTrue(deck.isEmpty());
        assertEquals(0, deck.size());
    }
    
    @Test
    @DisplayName("maintain FIFO behavior for cards")
    public void testFIFOBehavior() {
        CardDeck deck = new CardDeck(1);
        Card card1 = new Card(1);
        Card card2 = new Card(2);
        Card card3 = new Card(3);
        
        deck.addCard(card1);
        deck.addCard(card2);
        deck.addCard(card3);
        
        assertEquals(3, deck.size());
        assertFalse(deck.isEmpty());
        
        assertEquals(card1, deck.drawCard());
        assertEquals(card2, deck.drawCard());
        assertEquals(card3, deck.drawCard());
        
        assertTrue(deck.isEmpty());
    }
    
    @Test
    @DisplayName("return null when drawing from empty deck")
    public void testDrawFromEmptyDeck() {
        CardDeck deck = new CardDeck(1);
        assertNull(deck.drawCard());
    }
    
    @Test
    @DisplayName("handle concurrent operations safely")
    public void testConcurrentDeckOperations() throws InterruptedException {
        CardDeck deck = new CardDeck(1);
        ExecutorService executor = Executors.newFixedThreadPool(10);
        final int operations = 100;
        
        for (int i = 0; i < operations; i++) {
            final int cardValue = i;
            executor.submit(() -> deck.addCard(new Card(cardValue)));
        }
        
        Thread.sleep(100);
        
        // get cards concurrently
        for (int i = 0; i < operations; i++) {
            executor.submit(() -> deck.drawCard());
        }
        
        executor.shutdown();
        assertTrue(executor.awaitTermination(10, TimeUnit.SECONDS));
        
        assertTrue(deck.isEmpty());
    }

    @Test
    @DisplayName("make player with correct initial state")
    public void testPlayerCreation() {
        CardDeck leftDeck = new CardDeck(1);
        CardDeck rightDeck = new CardDeck(2);
        AtomicInteger winningPlayer = new AtomicInteger(0);
        
        Player player = new Player(1, leftDeck, rightDeck, winningPlayer);
        assertNotNull(player);
        assertEquals(1, player.getPlayerNumber());
    }
    
    @Test
    @DisplayName("handles initial hand setup correctly")
    public void testPlayerInitialHand() {
        CardDeck leftDeck = new CardDeck(1);
        CardDeck rightDeck = new CardDeck(2);
        AtomicInteger winningPlayer = new AtomicInteger(0);
        
        Player player = new Player(1, leftDeck, rightDeck, winningPlayer);
        
        player.addCardToHand(new Card(1));
        player.addCardToHand(new Card(2));
        player.addCardToHand(new Card(3));
        player.addCardToHand(new Card(4));
        
        assertFalse(player.hasWinningHand());
    }
    
    @Test
    @DisplayName("detect winning condition")
    public void testPlayerWinningCondition() {
        CardDeck leftDeck = new CardDeck(1);
        CardDeck rightDeck = new CardDeck(2);
        AtomicInteger winningPlayer = new AtomicInteger(0);
        
        Player player = new Player(1, leftDeck, rightDeck, winningPlayer);
        
        //winning hand
        player.addCardToHand(new Card(1));
        player.addCardToHand(new Card(1));
        player.addCardToHand(new Card(1));
        player.addCardToHand(new Card(1));
        
        assertTrue(player.hasWinningHand());
    }

    @Test
    @DisplayName("handle immediate win scenario")
    public void testImmediateWinScenario() throws IOException {
        String input = "2\n" + testPackFile + "\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        try {
            CardGame.main(new String[]{});
            
            String output = outputContent.toString();
        
            assertTrue(output.contains("wins"));
            
            //check output files
            assertTrue(new File("player1_output.txt").exists());
            assertTrue(new File("player2_output.txt").exists());
            assertTrue(new File("deck1_output.txt").exists());
            assertTrue(new File("deck2_output.txt").exists());
            
        } finally {
            System.setIn(System.in);
        }
    }
    
    @Test
    @DisplayName("should handle invalid pack file")
    public void testInvalidPackFileHandling() throws IOException {
        //make invaldi pack file
        String invalidPackFile = "invalid_pack.txt";
        try (PrintWriter writer = new PrintWriter(new FileWriter(invalidPackFile))) {
            writer.println("1");
            writer.println("2");
        }
        
        String input = "2\n" + invalidPackFile + "\n" + testPackFile + "\n";
        System.setIn(new ByteArrayInputStream(input.getBytes()));
        
        try {
            CardGame.main(new String[]{});
            String output = outputContent.toString();
            assertTrue(output.contains("Error: Pack must contain exactly 16 cards"));
        } finally {
            new File(invalidPackFile).delete();
            System.setIn(System.in);
        }
    }
}